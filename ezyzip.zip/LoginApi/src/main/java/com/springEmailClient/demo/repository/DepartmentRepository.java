package com.springEmailClient.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springEmailClient.demo.models.Department;

public interface DepartmentRepository extends JpaRepository<Department,Long> {



}
