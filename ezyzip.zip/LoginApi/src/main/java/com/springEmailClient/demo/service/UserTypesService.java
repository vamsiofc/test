package com.springEmailClient.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.springEmailClient.demo.models.UserTypes;
import com.springEmailClient.demo.repository.UserTypesRepository;

@Service
public class UserTypesService {
	
	@Autowired
	private UserTypesRepository userTypesRepository;

	public List<UserTypes> getUser() {
		return userTypesRepository.findAll();
	}

	
	public List<UserTypes> addNewUser(@RequestBody List<UserTypes>  users) {
   return userTypesRepository.saveAll(users);
	}
	
	
	
	public void deleteUser(Long id) {
	 Boolean exists=userTypesRepository.existsById(id);
	 if(!exists) {
		 System.out.println("user doesnot exist"+id);
	 }
	 userTypesRepository.deleteById(id);
		 
	}


	public void save(List<UserTypes> users) {
		// TODO Auto-generated method stub
		
	}


	
}
		