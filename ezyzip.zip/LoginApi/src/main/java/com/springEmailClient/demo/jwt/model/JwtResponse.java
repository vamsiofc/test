package com.springEmailClient.demo.jwt.model;

/**
 * @author vamsi.seshachalam
 *
 */
public class JwtResponse {
	String token;
	
	public JwtResponse() {
		
	}

	public JwtResponse(String token2) {
		// TODO Auto-generated constructor stub
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
	
	

}
