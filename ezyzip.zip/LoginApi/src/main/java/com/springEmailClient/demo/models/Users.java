package com.springEmailClient.demo.models;
import java.sql.Date;
import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Min;
import javax.validation.constraints.Size;

import com.sun.istack.NotNull;

@Entity
public class Users {
	
	@Id
    //private Long id;
	@NotNull
	@Size(min=2,message="name should have atleast 2 chars")
	@Column(name="username")
	private String username;
	@NotNull
	@Min(18)
	private Integer age;
	private Date date_of_birth;
//	@NotNull
//	@Size(min=10,message="number must 10 digits")
	private Long user_number;
	private String password;
	private Boolean is_active;
	private LocalDate created_on;
	private LocalDate updated_on;
	

	public Users() {
		
	}


	@ManyToOne
	private Employee Employee;
	
	public Users( String name, Integer age, Date date_of_birth, Long user_number, String password,
			Boolean is_active, LocalDate created_on, LocalDate updated_on) {
//		this.id = id;
		this.username = name;
		this.age = age;
		this.date_of_birth = date_of_birth;
		this.user_number = user_number;
		this.password = password;
		this.is_active = is_active;
		this.created_on = created_on;
		this.updated_on = updated_on;
	}


//	public Long getId() {
//		return id;
//	}

//
//	public void setId(Long id) {
//		this.id = id;
//	}


	public String getName() {
		return username;
	}


	public void setName(String name) {
		this.username = name;
	}


	public Integer getAge() {
		return age;
	}


	public void setAge(Integer age) {
		this.age = age;
	}


	public Date getDate_of_birth() {
		return date_of_birth;
	}


	public void setDate_of_birth(Date date_of_birth) {
		this.date_of_birth = date_of_birth;
	}


	public Long getUser_number() {
		return user_number;
	}


	public void setUser_number(Long user_number) {
		this.user_number = user_number;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public Boolean getIs_active() {
		return is_active;
	}


	public void setIs_active(Boolean is_active) {
		this.is_active = is_active;
	}


	public LocalDate getCreated_on() {
		return created_on;
	}


	public void setCreated_on(LocalDate created_on) {
		this.created_on = created_on;
	}


	public LocalDate getUpdated_on() {
		return updated_on;
	}


	public void setUpdated_on(LocalDate updated_on) {
		this.updated_on = updated_on;
	}


	@Override
	public String toString() {
		return "Users [ name=" + username + ", age=" + age + ", date_of_birth=" + date_of_birth
				+ ", user_number=" + user_number + ", password=" + password + ", is_active=" + is_active
				+ ", created_on=" + created_on + ", updated_on=" + updated_on + "]";
	}
	
	

	
	
}

	
	
	