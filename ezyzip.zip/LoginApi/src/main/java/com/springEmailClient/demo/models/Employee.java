package com.springEmailClient.demo.models;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.*;

@Entity
@Table
public class Employee {
@Id
@SequenceGenerator(
		name="student_sequence",
		sequenceName ="student_sequence",
		allocationSize =1
		)
@GeneratedValue(
		strategy =GenerationType.SEQUENCE,
		generator ="student_sequence"
		)
private Long id;
private LocalDate date_of_joining;
private LocalDate created_on;
private LocalDate updated_on;
private boolean is_active;
private Long user_id;
private Long dept_id;


//@ManyToOne
//private Department Department;

public Employee() {
}
public Employee(Long id, LocalDate date_of_joining, LocalDate created_on, LocalDate updated_on, boolean is_active, Long user_id,
		Long dept_id) {
	super();
	this.id = id;
	this.date_of_joining = date_of_joining;
	this.created_on = created_on;
	this.updated_on = updated_on;
	this.is_active = is_active;
	this.user_id = user_id;
	this.dept_id = dept_id;
}
public Employee(LocalDate date_of_joining, LocalDate created_on, LocalDate updated_on, boolean is_active, long user_id, long dept_id) {
	// TODO Auto-generated constructor stub
}
public Long getId() {
	return id;
}
public void setId(Long id) {
	this.id = id;
}
public LocalDate getDate_of_joining() {
	return date_of_joining;
}
public void setDate_of_joining(LocalDate date_of_joining) {
	this.date_of_joining = date_of_joining;
}
public LocalDate getCreated_on() {
	return created_on;
}
public void setCreated_on(LocalDate created_on) {
	this.created_on = created_on;
}
public LocalDate getUpdated_on() {
	return updated_on;
}
public void setUpdated_on(LocalDate updated_on) {
	this.updated_on = updated_on;
}
public boolean isIs_active() {
	return is_active;
}
public void setIs_active(boolean is_active) {
	this.is_active = is_active;
}
public Long getUser_id() {
	return user_id;
}
public void setUser_id(Long user_id) {
	this.user_id = user_id;
}
public Long getDept_id() {
	return dept_id;
}
public void setDept_id(Long dept_id) {
	this.dept_id = dept_id;
}
@Override
public String toString() {
	return "Employee [id=" + id + ", date_of_joining=" + date_of_joining + ", created_on=" + created_on
			+ ", updated_on=" + updated_on + ", is_active=" + is_active + ", user_id=" + user_id + ", dept_id="
			+ dept_id + "]";
}

}
