package com.springEmailClient.demo.models;


import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class UserTypes {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private String user_type_name;
	private LocalDate created_on;
	private LocalDate updated_on;
	private boolean is_active;
	public UserTypes(Long id, String user_type_name, LocalDate created_on, LocalDate updated_on, boolean is_active) {
		super();
		this.id = id;
		this.user_type_name = user_type_name;
		this.created_on = created_on;
		this.updated_on = updated_on;
		this.is_active = is_active;
	}
	
	public UserTypes() {
		
	}

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUser_type_name() {
		return user_type_name;
	}
	public void setUser_type_name(String user_type_name) {
		this.user_type_name = user_type_name;
	}
	public LocalDate getCreated_on() {
		return created_on;
	}
	public void setCreated_on(LocalDate created_on) {
		this.created_on = created_on;
	}
	public LocalDate getUpdated_on() {
		return updated_on;
	}
	public void setUpdated_on(LocalDate updated_on) {
		this.updated_on = updated_on;
	}
	public boolean isIs_active() {
		return is_active;
	}
	public void setIs_active(boolean is_active) {
		this.is_active = is_active;
	}
	@Override
	public String toString() {
		return "UserTypes [id=" + id + ", user_type_name=" + user_type_name + ", created_on=" + created_on
				+ ", updated_on=" + updated_on + ", is_active=" + is_active + "]";
	}

}
