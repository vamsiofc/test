package com.springEmailClient.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.springEmailClient.demo.models.Department;
import com.springEmailClient.demo.service.DepartmentService;

@RestController
@RequestMapping(path="api/Department")
public class DepartmentController {
	
	@Autowired
	private DepartmentService departmentService;

	@GetMapping
	public List<Department> getUsers(){
		return departmentService.getUsers();
	}
     @PostMapping
     public List<Department> addNewUser(@Valid @RequestBody List<Department>  users) {
		return departmentService.addNewUser(users);
		
	}
     
	@DeleteMapping(path="{id}")
     public void deleteUser(@PathVariable("id")Long id) {
      departmentService.deleteUser(id);	
	}
	
	
}