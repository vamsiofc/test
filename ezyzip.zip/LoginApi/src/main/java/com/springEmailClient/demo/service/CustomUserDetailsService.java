package com.springEmailClient.demo.service;

import java.util.ArrayList;

import org.apache.tomcat.jni.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;


@Service
public class CustomUserDetailsService implements UserDetailsService {

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
if(username.equals("vamsi"))
{
	return (UserDetails) new User();
}else {
	throw new UsernameNotFoundException("User not found");
}
		
		
	}

}
