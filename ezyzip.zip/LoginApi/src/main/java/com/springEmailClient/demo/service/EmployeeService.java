package com.springEmailClient.demo.service;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.springEmailClient.demo.models.Employee;
import com.springEmailClient.demo.repository.EmployeeRepository;


@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeRepository employeeRepository;
	public Optional<Employee> getAllById;

	public List<Employee> getUsers() {
		return employeeRepository.findAll();
	}
	public List<Employee> getUserById(@RequestBody List<Employee> user) {
		return employeeRepository.findAllById(getId());
	}

	
	private Iterable<Long> getId() {
		// TODO Auto-generated method stub
		return null;
	}
	public List<Employee> addNewUser(@RequestBody List<Employee>  employee) {
   return employeeRepository.saveAll(employee);
	}
      
	
	public List<Employee> updateUser(@RequestBody List<Employee>  dept) {
		   return employeeRepository.saveAll(dept);
			}
	
	public void deleteUser(Long id) {
	 Boolean exists=employeeRepository.existsById(id);
	 if(!exists) {
		 System.out.println("Employee doesnot exist"+id);
	 }
	 employeeRepository.deleteById(id);
		 
	}


	
}
		
	
	