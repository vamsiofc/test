package com.springEmailClient.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springEmailClient.demo.models.Employee;

public interface EmployeeRepository extends JpaRepository<Employee,Long> {

}
