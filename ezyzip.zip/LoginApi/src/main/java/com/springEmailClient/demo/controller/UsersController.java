package com.springEmailClient.demo.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springEmailClient.demo.models.Users;
import com.springEmailClient.demo.service.UsersService;

@RestController
@RequestMapping(path="api/Users")
public class UsersController {
	
	@Autowired    
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	@Autowired
	private UsersService usersService;

	@GetMapping
	public List<Users> getUsers(){
		return usersService.getUsers();
	}
     @PostMapping
    
     public Users addNewUser(@Valid @RequestBody Users  users) {
		return usersService.addNewUser(users);
		
	}
     @PutMapping
     public List<Users> updateUser(@Valid @RequestBody List<Users>  users) {
		return usersService.updateUser(users);
		
	}
     
	@DeleteMapping(path="{name}")
     public void deleteUser(@PathVariable("name")String name) {
      usersService.deleteUser(name);	
	}
	
	
	

}
	
	

	
	

	

	
	
	
	
	
	
	
	
	
	
	
	
	
	


