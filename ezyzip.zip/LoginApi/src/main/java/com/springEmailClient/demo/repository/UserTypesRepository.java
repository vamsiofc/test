package com.springEmailClient.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springEmailClient.demo.models.UserTypes;

public interface UserTypesRepository extends JpaRepository<UserTypes,Long> {

}
