package com.springEmailClient.demo.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.springEmailClient.demo.models.Users;
import com.springEmailClient.demo.repository.UsersRepository;


@Service
public class UsersService {
	
	@Autowired
	private UsersRepository usersRepository;
	
	

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	

	public UsersService() {
		
	}


	public List<Users> getUsers() {
		return usersRepository.findAll();
	}

	
	public Users addNewUser(@RequestBody Users  users) {
		String encodedPassword = bCryptPasswordEncoder.encode(users.getPassword());

		users.setPassword(encodedPassword);
   return usersRepository.save(users);
	}
	
	public List<Users> updateUser(@RequestBody List<Users>  dept) {
		   return usersRepository.saveAll(dept);
			}
      
	
	public void deleteUser(String name) {
	 Boolean exists=usersRepository.existsById(name);
	 if(!exists) {
		 System.out.println("user doesnot exist"+name);
	 }
	 usersRepository.deleteById(name);
		 
	}


	
}
		
	
	

	

		
	
	
	
		
	
	

