package com.springEmailClient.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.springEmailClient.demo.models.Department;
import com.springEmailClient.demo.repository.DepartmentRepository;


@Service
public class DepartmentService {
	
	@Autowired
	private DepartmentRepository departmentRepository;

	public List<Department> getUsers() {
		return departmentRepository.findAll();
	}


	
	public List<Department> addNewUser(@RequestBody List<Department>  dept) {
   return departmentRepository.saveAll(dept);
	}
	
	
	public void deleteUser(Long id) {
	 Boolean exists=departmentRepository.existsById(id);
	 if(!exists) {
		 System.out.println("user doesnot exist"+id);
	 }
	 departmentRepository.deleteById(id);
		 
	}
	
	


	
}
		