package com.springEmailClient.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springEmailClient.demo.models.Employee;
import com.springEmailClient.demo.repository.EmployeeRepository;
import com.springEmailClient.demo.service.EmployeeService;

@RestController
@RequestMapping(path="api/Employee")
public class EmployeeController {
	
	
	
	@Autowired
	private EmployeeRepository employeeRepository;

	
	@Autowired
	private EmployeeService employeeService;

	@GetMapping
	public List<Employee> getUsers(){
		return employeeService.getUsers();
	}
	
	@GetMapping(path="{id}")
	public Optional<Employee> getById(@PathVariable("id")Long id){
		return employeeService.getAllById;
	}

     @PostMapping
     public List<Employee> addNewUser(@RequestBody List<Employee>  users) {
		return employeeService.addNewUser(users);
		
	}
     
     @PutMapping("/employees/{id}")
     public ResponseEntity<Employee> updateEmployee(@PathVariable(value = "id") Long employeeId,
       @Validated @RequestBody Employee employeeDetails) throws Exception {
          Employee employee = employeeRepository.findById(employeeId)
          .orElseThrow(() -> new Exception("Employee not found for this id :: " + employeeId));

          employee.setDate_of_joining(employeeDetails.getDate_of_joining());
          employee.setCreated_on(employeeDetails.getCreated_on());
          employee.setUpdated_on(employeeDetails.getUpdated_on());
          employee.setIs_active(employeeDetails.isIs_active());
          employee.setUser_id(employeeDetails.getUser_id());
          employee.setDept_id(employeeDetails.getDept_id());

          final Employee updatedEmployee = employeeRepository.save(employee);
          return ResponseEntity.ok(updatedEmployee);
     }
     
	@DeleteMapping(path="{id}")
     public void deleteUser(@PathVariable("id")Long id) {
      employeeService.deleteUser(id);	
	}
}