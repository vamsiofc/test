package com.springEmailClient.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springEmailClient.demo.models.UserTypes;
import com.springEmailClient.demo.service.UserTypesService;

@RestController
@RequestMapping(path="api/UserTypes")
public class UserTypesController {
	
	@Autowired
	private UserTypesService userTypesService;

	@GetMapping
	public List<UserTypes> getUser(){
		return userTypesService.getUser();
	}
     @PostMapping
     public List<UserTypes> addNewUser(@RequestBody List<UserTypes>  users) {
		return userTypesService.addNewUser(users);
		
	}
    
   
     
	@DeleteMapping(path="{id}")
     public void deleteUser(@PathVariable("id")Long id) {
      userTypesService.deleteUser(id);	
	}
}