package userRepository;

public class findByUserNumber {

}
